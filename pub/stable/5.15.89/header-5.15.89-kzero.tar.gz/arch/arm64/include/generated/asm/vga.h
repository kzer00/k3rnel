#include <asm-generic/vga.h>
