#include <asm-generic/parport.h>
