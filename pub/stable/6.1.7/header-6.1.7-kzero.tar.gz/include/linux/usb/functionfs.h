/* SPDX-License-Identifier: GPL-2.0 */
#ifndef __LINUX_FUNCTIONFS_H__
#define __LINUX_FUNCTIONFS_H__ 1

#include <uapi/linux/usb/functionfs.h>

#endif
