/* SPDX-License-Identifier: GPL-2.0 */
#ifndef _LINUX_SEG6_H
#define _LINUX_SEG6_H

#include <uapi/linux/seg6.h>

#endif
